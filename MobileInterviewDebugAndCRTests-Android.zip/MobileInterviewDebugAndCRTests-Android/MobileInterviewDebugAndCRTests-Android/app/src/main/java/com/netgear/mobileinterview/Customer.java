package com.netgear.mobileinterview;


public class Customer {

    public int customerId;
    public String firstName;
    public String lastName;

    public Customer(int customerId, String firstName, String lastName) {
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
